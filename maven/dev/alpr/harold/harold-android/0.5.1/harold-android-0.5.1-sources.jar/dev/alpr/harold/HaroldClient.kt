package dev.alpr.harold

import android.app.Activity
import android.app.Application
import android.content.Context
import android.os.Bundle
import android.util.Base64
import android.util.Log

/** Writes to Logcat. */
internal val logcatSink = ConsoleSink { level, tag, message ->
    Log.println(level.priority(), tag, message)
}

internal fun Level.priority(): Int =
    when (this) {
        Level.DEBUG -> Log.DEBUG
        Level.INFO -> Log.INFO
        Level.WARNING -> Log.WARN
        Level.ERROR -> Log.ERROR
    }

/** The application, or `null` when [applicationContext] is not an [Application]. */
internal fun asApplication(applicationContext: Any?): Application? = applicationContext as? Application

/** The instance behind [Harold]. */
internal class HaroldClient(private val console: ConsoleSink = logcatSink) {
    val overrides = HaroldOverrides()
    private val queue = LogQueue()
    private val stateBox = StateBox()
    private val lock = Any()
    private var thread: Thread? = null

    fun start(context: Context, bufferCapacity: Int) {
        val application = asApplication(context.applicationContext)
        if (application == null) {
            console.write(Level.WARNING, "Harold", "Harold.start needs an Application context. The SDK did not start.")
            return
        }
        queue.activate(bufferCapacity)
        application.registerActivityLifecycleCallbacks(LaunchOverridesWatcher(application, overrides))
        val builder = HelloBuilder(application)
        val hosts = if (isEmulator()) listOf("127.0.0.1", "10.0.2.2") else listOf("127.0.0.1")
        val session =
            HaroldSession(
                hello = { builder.make() },
                queue = queue,
                stateBox = stateBox,
                overrides = overrides,
                dependencies =
                    SessionDependencies(
                        hosts = hosts,
                        makeTransport = { OkHttpTransport() },
                        sleep = { Thread.sleep(it) },
                        console = console,
                    ),
            )
        val next = Thread({ session.run() }, "harold-session").apply { isDaemon = true }
        synchronized(lock) {
            thread?.interrupt()
            thread = next
        }
        next.start()
    }

    fun log(message: String, level: Level, category: String, metadata: Map<String, String>) {
        console.write(level, category, message)
        queue.record(message, level, category, metadata)
    }

    fun state(values: Map<String, String>) {
        stateBox.set(values)
        queue.wake.signal()
    }

    fun setStateProvider(provider: (() -> Map<String, String>)?) = stateBox.setProvider(provider)
}

/** Reads the `harold_overrides` extra of the first activity that starts, then removes itself. */
private class LaunchOverridesWatcher(
    private val application: Application,
    private val overrides: HaroldOverrides,
) : Application.ActivityLifecycleCallbacks {
    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
        application.unregisterActivityLifecycleCallbacks(this)
        val payload = activity.intent?.getStringExtra(LAUNCH_EXTRA)
        overrides.apply(decodeLaunchOverrides(payload) { Base64.decode(it, Base64.DEFAULT) })
    }

    override fun onActivityStarted(activity: Activity) {}

    override fun onActivityResumed(activity: Activity) {}

    override fun onActivityPaused(activity: Activity) {}

    override fun onActivityStopped(activity: Activity) {}

    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}

    override fun onActivityDestroyed(activity: Activity) {}

    private companion object {
        const val LAUNCH_EXTRA = "harold_overrides"
    }
}
