package dev.alpr.harold

import java.util.concurrent.BlockingQueue
import java.util.concurrent.atomic.AtomicBoolean

/** What the session thread waits for. */
internal sealed class SessionEvent {
    data object Opened : SessionEvent()

    data class Received(val text: String) : SessionEvent()

    data object Closed : SessionEvent()

    data object Wake : SessionEvent()
}

/** Wakes the session thread. A signal never blocks the caller and never queues more than one wake. */
internal class WakeSignal {
    private val lock = Any()
    private var inbox: BlockingQueue<SessionEvent>? = null
    private val pending = AtomicBoolean(false)

    /** Binds a new inbox and wakes it once at once. */
    fun bind(inbox: BlockingQueue<SessionEvent>) {
        synchronized(lock) {
            this.inbox = inbox
            pending.set(true)
            inbox.offer(SessionEvent.Wake)
        }
    }

    /** Releases [inbox] when it is still the bound one. A newer session keeps its binding. */
    fun unbind(inbox: BlockingQueue<SessionEvent>) {
        synchronized(lock) { if (this.inbox === inbox) this.inbox = null }
    }

    fun signal() {
        synchronized(lock) {
            val target = inbox ?: return
            if (pending.compareAndSet(false, true)) target.offer(SessionEvent.Wake)
        }
    }

    /** Called by the session thread when it takes a wake, before it reads the queue. */
    fun consumed() {
        pending.set(false)
    }
}

/** The log entries that wait for the Mac. The owner of the ring buffer. */
internal class LogQueue(private val now: () -> Long = System::currentTimeMillis) {
    private val lock = Any()
    private var buffer = RingBuffer(1000)
    private var nextSeq = 0
    private var active = false

    val wake = WakeSignal()

    /** Empties the buffer, sets its size and starts to accept entries. */
    fun activate(capacity: Int) {
        synchronized(lock) {
            buffer = RingBuffer(capacity)
            active = true
        }
    }

    /** Queues an entry. Does nothing before [activate]. */
    fun record(message: String, level: Level, category: String, metadata: Map<String, String>) {
        val accepted =
            synchronized(lock) {
                if (!active) return@synchronized false
                nextSeq += 1
                buffer.append(LogEntry(nextSeq, now(), level, category, message, HashMap(metadata)))
                true
            }
        if (accepted) wake.signal()
    }

    fun nextBatch(limit: Int): LogBatch? = synchronized(lock) { buffer.nextBatch(limit) }

    fun remove(batch: LogBatch) = synchronized(lock) { buffer.remove(batch) }
}

/** The last state snapshot and the function that answers state requests. */
internal class StateBox {
    private val lock = Any()
    private var last: Map<String, String>? = null
    private var provider: (() -> Map<String, String>)? = null
    private var pending = false

    fun set(values: Map<String, String>) =
        synchronized(lock) {
            last = HashMap(values)
            pending = true
        }

    fun setProvider(provider: (() -> Map<String, String>)?) = synchronized(lock) { this.provider = provider }

    /** The snapshot that was set and not yet sent. */
    fun takePending(): Map<String, String>? =
        synchronized(lock) {
            if (!pending) return null
            pending = false
            last
        }

    fun markPending() = synchronized(lock) { pending = last != null }

    /** The answer to a state request: the provider's values, else the last snapshot. */
    fun answer(): Map<String, String>? {
        val provider = synchronized(lock) { provider }
        val values = provider?.invoke() ?: synchronized(lock) { last }
        synchronized(lock) {
            last = values
            pending = false
        }
        return values
    }
}
