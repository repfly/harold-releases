package dev.alpr.harold

import java.util.concurrent.atomic.AtomicBoolean

/** A handle for an override callback. Call [cancel] to stop it. */
class HaroldObservation internal constructor(private val onCancel: () -> Unit) {
    private val cancelled = AtomicBoolean(false)

    /** Stops the callback. Calling it twice is safe. */
    fun cancel() {
        if (cancelled.compareAndSet(false, true)) onCancel()
    }
}

/** String key/value overrides that the Harold app sends, with typed reads and change callbacks. */
class HaroldOverrides internal constructor() {
    private class Observer(val key: String?, val handler: (String, String?) -> Unit)

    private class Call(val handler: (String, String?) -> Unit, val key: String, val value: String?)

    private val lock = Any()
    private val values = HashMap<String, String>()
    private val observers = LinkedHashMap<Int, Observer>()
    private var nextId = 0

    /** All current values. */
    val all: Map<String, String>
        get() = synchronized(lock) { HashMap(values) }

    /** The raw value for [key], or `null`. */
    fun string(key: String): String? = synchronized(lock) { values[key] }

    /** The value as a boolean. `true`, `on`, `yes`, `1` and `false`, `off`, `no`, `0` (any case) are known. */
    fun bool(key: String): Boolean? =
        when (string(key)?.lowercase()) {
            "true", "on", "yes", "1" -> true
            "false", "off", "no", "0" -> false
            else -> null
        }

    /** The value as an integer, or `null` when it is missing or not a number. */
    fun int(key: String): Int? = string(key)?.toIntOrNull()

    /**
     * Runs [handler] when the value of [key] changes, or of any key when [key] is `null`.
     *
     * The handler gets the key and the new value (`null` when the key was removed).
     * It runs on an arbitrary thread, once for each change, and not for an equal value.
     */
    @JvmOverloads
    fun observe(key: String? = null, handler: (key: String, value: String?) -> Unit): HaroldObservation {
        val id =
            synchronized(lock) {
                nextId += 1
                observers[nextId] = Observer(key, handler)
                nextId
            }
        return HaroldObservation { synchronized(lock) { observers.remove(id) } }
    }

    /** Applies changes. A `null` value removes the key. Callbacks run after the lock is released. */
    internal fun apply(changes: Map<String, String?>) {
        val calls = ArrayList<Call>()
        synchronized(lock) {
            for (key in changes.keys.sorted()) {
                val newValue = changes[key]
                if (values[key] == newValue) continue
                if (newValue == null) values.remove(key) else values[key] = newValue
                for (observer in observers.values) {
                    if (observer.key == null || observer.key == key) {
                        calls.add(Call(observer.handler, key, newValue))
                    }
                }
            }
        }
        for (call in calls) {
            try {
                call.handler(call.key, call.value)
            } catch (_: Exception) {
                // A failing app callback must not stop the channel.
            }
        }
    }
}
