package dev.alpr.harold

import android.content.Context
import android.os.Build
import android.provider.Settings
import java.util.UUID

/** Builds the `hello` message from the device, the app and the install's device key. */
internal class HelloBuilder(private val context: Context, private val makeKey: () -> String = { UUID.randomUUID().toString() }) {
    /** The key is made once per install and kept in `SharedPreferences`. It never goes to a log. */
    fun deviceKey(): String {
        val preferences = context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)
        preferences.getString(KEY, null)?.let { return it }
        val key = makeKey()
        preferences.edit().putString(KEY, key).apply()
        return key
    }

    fun make(): Hello {
        val appID = context.packageName
        val appName = context.applicationInfo.loadLabel(context.packageManager).toString()
        val versionName =
            try {
                context.packageManager.getPackageInfo(appID, 0).versionName
            } catch (_: Exception) {
                null
            }
        return Hello(
            deviceKey = deviceKey(),
            deviceName = deviceName(),
            model = Build.MODEL,
            osVersion = Build.VERSION.RELEASE,
            simulator = isEmulator(),
            appID = appID,
            appName = appName,
            appVersion = versionName ?: "0",
        )
    }

    private fun deviceName(): String =
        try {
            Settings.Global.getString(context.contentResolver, "device_name")
        } catch (_: Exception) {
            null
        } ?: Build.MODEL

    private companion object {
        const val PREFERENCES = "dev.alpr.harold"
        const val KEY = "deviceKey"
    }
}

/** True on an Android emulator. */
internal fun isEmulator(): Boolean =
    Build.FINGERPRINT.startsWith("generic") ||
        Build.FINGERPRINT.contains("emulator") ||
        Build.HARDWARE == "goldfish" ||
        Build.HARDWARE == "ranchu" ||
        Build.MODEL.contains("Emulator") ||
        Build.MODEL.contains("Android SDK built for")
