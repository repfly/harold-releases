package dev.alpr.harold

import org.json.JSONObject

/** The version of this SDK. It goes into `hello`. */
internal const val HAROLD_SDK_VERSION = "0.1.0"

/** The first message of a connection (SDK to Mac). */
internal data class Hello(
    val deviceKey: String,
    val deviceName: String,
    val model: String,
    val osVersion: String,
    val simulator: Boolean,
    val appID: String,
    val appName: String,
    val appVersion: String,
    val sdk: String = "android",
    val sdkVersion: String = HAROLD_SDK_VERSION,
) {
    fun toJson(): String =
        JSONObject()
            .put("type", "hello")
            .put("protocol", 1)
            .put("sdk", sdk)
            .put("sdkVersion", sdkVersion)
            .put("deviceKey", deviceKey)
            .put("deviceName", deviceName)
            .put("model", model)
            .put("osVersion", osVersion)
            .put("simulator", simulator)
            .put("appID", appID)
            .put("appName", appName)
            .put("appVersion", appVersion)
            .toString()
}

/** One log entry on the wire. [seq] grows by one for each entry. [time] is in ms since 1970. */
internal data class LogEntry(
    val seq: Int,
    val time: Long,
    val level: Level,
    val category: String,
    val message: String,
    val metadata: Map<String, String>,
)

/** Up to a limit of queued entries and the count of entries dropped before them. */
internal data class LogBatch(val entries: List<LogEntry>, val dropped: Int)

internal fun encodeLog(batch: LogBatch): String {
    val entries = org.json.JSONArray()
    for (entry in batch.entries) {
        entries.put(
            JSONObject()
                .put("seq", entry.seq)
                .put("time", entry.time)
                .put("level", entry.level.wire)
                .put("category", entry.category)
                .put("message", entry.message)
                .put("metadata", JSONObject(entry.metadata))
        )
    }
    return JSONObject().put("type", "log").put("entries", entries).put("dropped", batch.dropped).toString()
}

internal fun encodeState(values: Map<String, String>): String =
    JSONObject().put("type", "state").put("values", JSONObject(values)).toString()

/** A message from the Mac. */
internal sealed class ServerMessage {
    data class Pairing(val code: String) : ServerMessage()

    data class Welcome(val sessionID: String) : ServerMessage()

    data class Rejected(val reason: String) : ServerMessage()

    /** A `null` value removes the key. */
    data class Override(val values: Map<String, String?>) : ServerMessage()

    data object StateRequest : ServerMessage()

    data class Unknown(val type: String) : ServerMessage()
}

/** Decodes a frame from the Mac. A bad frame gives `null`. */
internal fun parseServerMessage(text: String): ServerMessage? =
    try {
        val json = JSONObject(text)
        when (val type = json.getString("type")) {
            "pairing" -> ServerMessage.Pairing(json.getString("code"))
            "welcome" -> ServerMessage.Welcome(json.getString("sessionID"))
            "rejected" -> ServerMessage.Rejected(json.getString("reason"))
            "override" -> ServerMessage.Override(stringMap(json.getJSONObject("values")))
            "stateRequest" -> ServerMessage.StateRequest
            else -> ServerMessage.Unknown(type)
        }
    } catch (_: Exception) {
        null
    }

private fun stringMap(json: JSONObject): Map<String, String?> {
    val result = LinkedHashMap<String, String?>()
    for (key in json.keys()) {
        result[key] = if (json.isNull(key)) null else json.getString(key)
    }
    return result
}

/**
 * Decodes the launch payload: base64 of a JSON string map. A bad payload gives no values.
 * [decodeBase64] is a parameter because `java.util.Base64` needs API 26 and tests run on the JVM.
 */
internal fun decodeLaunchOverrides(payload: String?, decodeBase64: (String) -> ByteArray): Map<String, String> =
    try {
        if (payload == null) {
            emptyMap()
        } else {
            val json = JSONObject(String(decodeBase64(payload), Charsets.UTF_8))
            stringMap(json).filterValues { it != null }.mapValues { it.value!! }
        }
    } catch (_: Exception) {
        emptyMap()
    }
