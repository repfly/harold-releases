package dev.alpr.harold

import java.io.IOException
import java.util.concurrent.BlockingQueue
import java.util.concurrent.LinkedBlockingQueue

/** Where the SDK writes to the console. Tests replace it. */
internal fun interface ConsoleSink {
    fun write(level: Level, tag: String, message: String)
}

/** What a session needs from outside. Tests replace the transport and the sleep. */
internal class SessionDependencies(
    val hosts: List<String>,
    val makeTransport: () -> HaroldTransport,
    /** Waits the given milliseconds. It throws [InterruptedException] when the thread is cancelled. */
    val sleep: (Long) -> Unit,
    val console: ConsoleSink,
)

/**
 * The connection loop: connect, say hello, serve until the link breaks, wait, repeat.
 * It stops for good on `rejected`. The owner interrupts the thread that runs it.
 */
internal class HaroldSession(
    private val hello: () -> Hello,
    private val queue: LogQueue,
    private val stateBox: StateBox,
    private val overrides: HaroldOverrides,
    private val dependencies: SessionDependencies,
) {
    private val schedule = ReconnectSchedule()
    private var welcomed = false
    private var rejected = false

    /** Blocks until [rejected] or until the thread is interrupted. */
    fun run() {
        var failures = 0
        try {
            while (!rejected) {
                welcomed = false
                try {
                    serve()
                } catch (e: InterruptedException) {
                    throw e
                } catch (e: Exception) {
                    dependencies.console.write(Level.DEBUG, TAG, "Harold connection ended: ${e.javaClass.simpleName}")
                }
                if (welcomed) failures = 0
                if (rejected) break
                val delay = schedule.delayMillis(failures)
                failures += 1
                dependencies.sleep(delay)
            }
        } catch (_: InterruptedException) {
            // The owner cancelled the session.
        }
    }

    private class Attempt(val transport: HaroldTransport, val inbox: BlockingQueue<SessionEvent>)

    private fun serve() {
        val attempt = open() ?: return
        try {
            if (!attempt.transport.send(hello().toJson())) return
            while (true) {
                when (val event = attempt.inbox.take()) {
                    SessionEvent.Closed -> return
                    SessionEvent.Opened -> {}
                    SessionEvent.Wake -> {
                        queue.wake.consumed()
                        if (welcomed) flush(attempt.transport)
                    }
                    is SessionEvent.Received -> {
                        handle(event.text, attempt.transport)
                        if (rejected) return
                    }
                }
            }
        } finally {
            queue.wake.unbind(attempt.inbox)
            attempt.transport.close()
        }
    }

    /** Tries each host in turn. The first one that opens wins. */
    private fun open(): Attempt? {
        for (host in dependencies.hosts) {
            val inbox = LinkedBlockingQueue<SessionEvent>()
            val transport = dependencies.makeTransport()
            transport.connect(
                haroldChannelURL(host),
                object : TransportListener {
                    override fun onOpen() {
                        inbox.offer(SessionEvent.Opened)
                    }

                    override fun onMessage(text: String) {
                        inbox.offer(SessionEvent.Received(text))
                    }

                    override fun onClosed(error: Throwable?) {
                        inbox.offer(SessionEvent.Closed)
                    }
                },
            )
            try {
                while (true) {
                    when (inbox.take()) {
                        SessionEvent.Opened -> {
                            queue.wake.bind(inbox)
                            return Attempt(transport, inbox)
                        }
                        SessionEvent.Closed -> break
                        else -> {}
                    }
                }
            } catch (e: InterruptedException) {
                transport.close()
                throw e
            }
            transport.close()
        }
        return null
    }

    private fun handle(text: String, transport: HaroldTransport) {
        when (val message = parseServerMessage(text)) {
            is ServerMessage.Pairing ->
                dependencies.console.write(Level.INFO, TAG, "Harold pairing code: ${message.code}")
            is ServerMessage.Welcome -> {
                welcomed = true
                queue.wake.signal()
            }
            is ServerMessage.Rejected -> {
                dependencies.console.write(Level.ERROR, TAG, "Harold rejected this app: ${message.reason}")
                rejected = true
            }
            is ServerMessage.Override -> overrides.apply(message.values)
            ServerMessage.StateRequest -> stateBox.answer()?.let { send(transport, encodeState(it)) }
            is ServerMessage.Unknown, null -> {}
        }
    }

    private fun flush(transport: HaroldTransport) {
        stateBox.takePending()?.let {
            try {
                send(transport, encodeState(it))
            } catch (e: IOException) {
                stateBox.markPending()
                throw e
            }
        }
        while (true) {
            val batch = queue.nextBatch(MAX_BATCH_ENTRIES) ?: break
            send(transport, encodeLog(batch))
            queue.remove(batch)
        }
    }

    private fun send(transport: HaroldTransport, text: String) {
        if (!transport.send(text)) throw IOException("The link is down.")
    }

    private companion object {
        const val TAG = "Harold"
        const val MAX_BATCH_ENTRIES = 100
    }
}
