package dev.alpr.harold

/** A bounded queue of log entries. It drops the oldest entry first and counts the drops. Not thread-safe. */
internal class RingBuffer(capacity: Int) {
    val capacity: Int = maxOf(1, capacity)
    private val items = ArrayDeque<LogEntry>()

    /** How many entries the buffer dropped and the Mac does not know about. */
    var dropped = 0
        private set

    val entries: List<LogEntry>
        get() = items.toList()

    fun append(entry: LogEntry) {
        if (items.size >= capacity) {
            items.removeFirst()
            dropped += 1
        }
        items.addLast(entry)
    }

    /** The oldest entries, at most [limit]. The batch stays queued until [remove]. */
    fun nextBatch(limit: Int): LogBatch? {
        if (items.isEmpty()) return null
        return LogBatch(items.take(limit), dropped)
    }

    /** Removes a sent batch. Entries and drops that came after [nextBatch] stay. */
    fun remove(batch: LogBatch) {
        val last = batch.entries.lastOrNull()?.seq
        if (last != null) {
            while (items.isNotEmpty() && items.first().seq <= last) items.removeFirst()
        }
        dropped = maxOf(0, dropped - batch.dropped)
    }
}
