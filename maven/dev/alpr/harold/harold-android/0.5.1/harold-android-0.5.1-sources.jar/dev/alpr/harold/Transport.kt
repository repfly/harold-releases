package dev.alpr.harold

import java.net.Proxy
import java.util.concurrent.TimeUnit
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener

/** Receives the events of one connection attempt. Calls come from any thread. */
internal interface TransportListener {
    fun onOpen()

    fun onMessage(text: String)

    /** The link is down or never came up. [error] is `null` for a normal close. */
    fun onClosed(error: Throwable?)
}

/** One WebSocket connection to the Harold app. A new value is made for each attempt. */
internal interface HaroldTransport {
    /** Starts to connect. It does not block. The result comes to [listener]. */
    fun connect(url: String, listener: TransportListener)

    /** Queues a text frame. `false` when the link is not up. */
    fun send(text: String): Boolean

    /** Closes the connection. It is safe to call more than once. */
    fun close()
}

/** The loopback address of the Harold app (ADR 0020). */
internal fun haroldChannelURL(host: String): String = "ws://$host:47391/harold/v1"

private val sharedClient: OkHttpClient by lazy {
    // NO_PROXY: the channel to the app must not go through the global proxy that Harold sets.
    OkHttpClient.Builder().proxy(Proxy.NO_PROXY).connectTimeout(3, TimeUnit.SECONDS).build()
}

/** OkHttp transport. */
internal class OkHttpTransport(private val client: OkHttpClient = sharedClient) : HaroldTransport {
    @Volatile private var socket: WebSocket? = null

    override fun connect(url: String, listener: TransportListener) {
        val request = Request.Builder().url(url).build()
        socket =
            client.newWebSocket(
                request,
                object : WebSocketListener() {
                    override fun onOpen(webSocket: WebSocket, response: Response) = listener.onOpen()

                    override fun onMessage(webSocket: WebSocket, text: String) = listener.onMessage(text)

                    override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                        webSocket.close(code, null)
                    }

                    override fun onClosed(webSocket: WebSocket, code: Int, reason: String) = listener.onClosed(null)

                    override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) =
                        listener.onClosed(t)
                },
            )
    }

    override fun send(text: String): Boolean = socket?.send(text) ?: false

    override fun close() {
        socket?.cancel()
    }
}
