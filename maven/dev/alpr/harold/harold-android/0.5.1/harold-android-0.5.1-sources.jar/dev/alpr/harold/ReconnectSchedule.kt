package dev.alpr.harold

/** The wait before each reconnect: 1, 2 and 5 seconds, then 10 seconds. */
internal class ReconnectSchedule {
    private val steps = longArrayOf(1_000, 2_000, 5_000)
    private val steady = 10_000L

    fun delayMillis(afterFailures: Int): Long = if (afterFailures < steps.size) steps[afterFailures] else steady
}
