package dev.alpr.harold

import android.content.Context

/**
 * The entry point of the Harold SDK.
 *
 * After [start], the calls reach the Harold app on the Mac. Before it, [log] writes only to Logcat.
 * No call blocks the caller or throws.
 */
object Harold {
    private val client = HaroldClient()

    /**
     * Connects to the Harold app on `127.0.0.1` (then `10.0.2.2` on an emulator) and keeps the connection alive.
     *
     * The first call after an install makes the app show a pairing code. The code also goes to Logcat.
     * Overrides come from the `harold_overrides` extra of the first started activity.
     * @param bufferCapacity How many log entries the SDK keeps while the Mac is not reachable.
     */
    @JvmStatic
    @JvmOverloads
    fun start(context: Context, bufferCapacity: Int = 1000) {
        try {
            client.start(context, bufferCapacity)
        } catch (_: Exception) {
            // The SDK must never break the app.
        }
    }

    /** Writes a log entry to Logcat and queues it for the Harold app. It never blocks and never throws. */
    @JvmStatic
    @JvmOverloads
    fun log(
        message: String,
        level: Level = Level.INFO,
        category: String = "default",
        metadata: Map<String, String> = emptyMap(),
    ) {
        try {
            client.log(message, level, category, metadata)
        } catch (_: Exception) {
            // The SDK must never break the app.
        }
    }

    /** Sends a snapshot of the app state. The app can ask for it again with a state request. */
    @JvmStatic
    fun state(values: Map<String, String>) {
        try {
            client.state(values)
        } catch (_: Exception) {
            // The SDK must never break the app.
        }
    }

    /** Sets a function that answers state requests from the Harold app. `null` removes it. */
    @JvmStatic
    fun setStateProvider(provider: (() -> Map<String, String>)?) {
        client.setStateProvider(provider)
    }

    /** The override values that the Mac sends at launch and later. */
    @JvmStatic
    val overrides: HaroldOverrides
        get() = client.overrides
}
