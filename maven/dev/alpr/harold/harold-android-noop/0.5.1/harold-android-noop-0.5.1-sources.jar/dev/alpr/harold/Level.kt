package dev.alpr.harold

/** The severity of a log entry. */
enum class Level(internal val wire: String) {
    DEBUG("debug"),
    INFO("info"),
    WARNING("warning"),
    ERROR("error"),
}
