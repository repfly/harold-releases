package dev.alpr.harold

import android.content.Context
import android.util.Log

/** A handle for an override callback. Call [cancel] to stop it. */
class HaroldObservation internal constructor() {
    /** Stops the callback. Calling it twice is safe. */
    fun cancel() {}
}

/** The override values. In this artifact they are always empty. */
class HaroldOverrides internal constructor() {
    /** All current values. */
    val all: Map<String, String>
        get() = emptyMap()

    /** The raw value for [key], or `null`. */
    fun string(key: String): String? = null

    /** The value as a boolean, or `null`. */
    fun bool(key: String): Boolean? = null

    /** The value as an integer, or `null`. */
    fun int(key: String): Int? = null

    /** Never runs [handler]. */
    @JvmOverloads
    fun observe(key: String? = null, handler: (key: String, value: String?) -> Unit): HaroldObservation =
        HaroldObservation()
}

/**
 * The entry point of the Harold SDK, no-op artifact. It has the API of `harold-android`.
 * [log] writes to Logcat only. Nothing else does anything, and the artifact has no network code.
 */
object Harold {
    private val noOverrides = HaroldOverrides()

    /** Does nothing. */
    @JvmStatic
    @JvmOverloads
    @Suppress("UNUSED_PARAMETER")
    fun start(context: Context, bufferCapacity: Int = 1000) {}

    /** Writes a log entry to Logcat. It never blocks and never throws. */
    @JvmStatic
    @JvmOverloads
    fun log(
        message: String,
        level: Level = Level.INFO,
        category: String = "default",
        metadata: Map<String, String> = emptyMap(),
    ) {
        try {
            val priority =
                when (level) {
                    Level.DEBUG -> Log.DEBUG
                    Level.INFO -> Log.INFO
                    Level.WARNING -> Log.WARN
                    Level.ERROR -> Log.ERROR
                }
            Log.println(priority, category, message)
        } catch (_: Exception) {
            // The SDK must never break the app.
        }
    }

    /** Does nothing. */
    @JvmStatic
    @Suppress("UNUSED_PARAMETER")
    fun state(values: Map<String, String>) {}

    /** Does nothing. */
    @JvmStatic
    @Suppress("UNUSED_PARAMETER")
    fun setStateProvider(provider: (() -> Map<String, String>)?) {}

    /** Always empty. */
    @JvmStatic
    val overrides: HaroldOverrides
        get() = noOverrides
}
